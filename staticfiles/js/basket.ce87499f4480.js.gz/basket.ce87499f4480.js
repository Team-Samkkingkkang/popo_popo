function basket(status) {
    $.ajax({
        url: '',
        type: 'GET',
        data: {

        },
        dataType: 'json'
    })
}